package com.chanakya.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmsystemApplication.class, args);
	}

}
